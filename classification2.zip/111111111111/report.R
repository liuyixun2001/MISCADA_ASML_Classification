```{r}
  rm(list=ls())
  library(caret)
  library(mlr3)
  library(mlr3verse)
  library(mlr3tuning)
  library(precrec)
  library(DALEX)
  library(DALEXtra)
  library(tidyr)
  library(dplyr)
  library(psych)
  library(tibble)
  library(janitor)
  library(gtsummary)
  library(gt)
  library(ggplot2)
  library(ggthemes)


bank = read.csv("https://www.louisaslett.com/Courses/MISCADA/bank_personal_loan.csv")
bank = bank %>% mutate(Education = as.factor(Education),
                       Securities.Account = as.factor(Securities.Account),
                       CD.Account = as.factor(CD.Account),
                       Online = as.factor(Online),
                       CreditCard = as.factor(CreditCard)) %>% 
  filter(Experience >= 0) %>% clean_names()
  
# hotel = read.csv("hotels.csv")
# Problem description ----
describe(bank %>% select(age,experience,income, family,cc_avg),skew = FALSE) %>%
  rownames_to_column() %>% select(-vars) %>% gt() %>% fmt_number(decimals = 3)
# experience exist negative number, so drop these negative value
tbl_summary(bank, 
            by = personal_loan,
            include = c(age, experience,
                        income,
                        family,
                        cc_avg,
                        education,mortgage,securities_account,
                        cd_account,
                        online,
                        credit_card),
            statistic = list(all_continuous()  ~ "{mean} ± {sd}", 
                             all_categorical() ~ "{n} ({p}%)"),
            missing = "ifany",
            missing_text = "(Missing)",
            digits = list(all_continuous()  ~ 3,
                          all_categorical() ~ 3)
) %>% 
  add_n() %>%
  add_overall() %>%
  add_p(test = list(
    all_continuous() ~ "kruskal.test",
    all_categorical() ~ "chisq.test.no.correct" 
  ),
  pvalue_fun = ~style_pvalue(.x, digits = 3) 
  )
num_vars = c("age", "experience", "income", "cc_avg", "mortgage", "family")
bank %>%
  select(personal_loan, all_of(num_vars)) %>%
  pivot_longer(cols = -personal_loan, names_to = "Variable", values_to = "Value") %>%
  ggplot(aes(x = as.factor(personal_loan), y = Value)) +
  geom_violin(fill = "steelblue", alpha = 0.7) +
  facet_wrap(~ Variable, scales = "free_y") + 
  labs(title = "Numerical Variables vs. Personal Loan", x = "Personal Loan", y = "Value") +
  theme_base()
cat_vars = c("education", "securities_account", "cd_account", "online", "credit_card")
bank %>%
  select(personal_loan, all_of(cat_vars)) %>%
  pivot_longer(cols = -personal_loan, names_to = "Variable", values_to = "Value") %>%
  ggplot(aes(x = as.factor(Value), fill = as.factor(personal_loan))) +
  geom_bar(position = "dodge", alpha = 0.7) +
  facet_wrap(~ Variable, scales = "free_y") + 
  labs(title = "Categorical Variables vs. Personal Loan", 
       x = "Personal Loan", y = "Value",
       fill = "Person Loan") +
  scale_fill_calc() +
  theme_base() +
  theme(legend.position = "top")

# Model fitting ----
bank_select = bank %>% dplyr::select(-zip_code) %>%
  mutate(personal_loan = as.factor(personal_loan))
tsk = TaskClassif$new(id= "dd",backend = bank_select, target = "personal_loan")
set.seed(123)
id = partition(tsk, 0.8)
train = tsk$clone()$filter(id$train)
test = tsk$clone()$filter(id$test)

# data balance
table(train$data(cols = train$target_names))
set.seed(123)
pipe = mlr3pipelines::po("smotenc", k=3, over_ratio = 1)
train = pipe$train(list(train))$output
table(train$data(cols = train$target_names))

glm = lrn("classif.log_reg",predict_type = "prob")
rpart = lrn("classif.rpart",predict_type= "prob")
rf = lrn("classif.ranger",predict_type= "prob")

train_fun = function(learner,train,test,model_name,seed=123) {
  set.seed(seed)
  model_rr <- learner$train(train)
  pred <- model_rr$predict(test)
  res_measure <- pred$score(measures = msrs(c("classif.acc",
                                              "classif.auc",
                                              "classif.ce",
                                              "classif.specificity",
                                              "classif.sensitivity",
                                              "classif.recall",
                                              "classif.precision",
                                              "classif.fbeta")))
  aggre_df <- data.frame(Measure = toupper(sub(".*\\.", "", names(res_measure))), 
                         Value = res_measure) 
  colnames(aggre_df)[colnames(aggre_df) == "Value"] <- model_name
  conf <- pred$confusion
  return(list(model = model_rr,
              metrics = aggre_df,
              conf = conf,
              prediction = pred))
}

# base model
glm_train = train_fun(glm,train = train, test = test,model_name = "GLM")
rpart_train = train_fun(rpart,train = train, test = test,model_name = "RPART")
rf_train = train_fun(rf,train = train, test = test,model_name = "RF")
# saveRDS(glm_train,"rds/glm_train.rds")
# saveRDS(rpart_train,"rds/rpart_train.rds")
# saveRDS(rf_train,"rds/rf_train.rds")
# glm_train = readRDS("rds/glm_train.rds")
# rpart_train = readRDS("rds/rpart_train.rds")
# rf_train = readRDS("rds/rf_train.rds")

Metrics = glm_train$metrics %>% full_join(rpart_train$metrics,by="Measure") %>%
  full_join(rf_train$metrics,by="Measure")
Metrics %>% gt() %>% fmt_number(decimals = 4) %>% tab_header("Model Comparison")

# Model improvements ----
# hyperparamter tuning
# rf
search_space <- ps(
  num.trees = p_fct(levels = c(200,400,500,600,800)),
  mtry = p_int(lower = 4, upper = 8))
autotune <- mlr3tuning::AutoTuner$new(
  learner = rf,
  search_space = search_space,
  resampling = rsmp("cv", folds = 5),
  measure = msr("classif.acc"),
  terminator = trm("stagnation", threshold = .001),
  tuner = tnr("grid_search",resolution= 20)
)
set.seed(123)
autotune$train(train)
best_param <- autotune$tuning_result$learner_param_vals[[1]]
rf_tuning = lrn("classif.ranger",predict_type= "prob",
                mtry = best_param$mtry, num.trees = best_param$num.trees)
rf_tuning_train = train_fun(rf_tuning,train = train, test = test,model_name = "RF_tuning")
# saveRDS(rf_tuning_train,"rds/rf_tuning_train.rds")
# rf_tuning_train = readRDS("rds/rf_tuning_train.rds")
rf_tuning_train$metrics %>% gt() %>% fmt_number(decimals = 4) %>% tab_header("Random Forest After Tuning")

# Performance report ----
# ROC
final_model = rf_tuning_train
mlr3verse::autoplot(final_model$prediction,type="roc") +
  geom_text(aes(x = 0.2, y = 0.9, label = paste("AUC =", 
                                                round(final_model$metrics$RF_tuning[2], 4))), 
            size = 5, color = "darkred") +
  ggtitle("ROC for Random Forest") +
  theme_pander()
# calibration
predictions = final_model$prediction
prediction_df=data.frame(obs = predictions$data$truth, pred = predictions$data$prob[,1])
cal_df <- calibration(obs~pred,data = prediction_df,cut=5)
xyplot(cal_df,xlab="Predicted Probablity (%)",
       col = "darkred", lwd = 2,main = "Calibration Cruve")

train_set = as.data.frame(train$data(cols=train$feature_names))
Y_train = as.numeric(as.vector((train$data(cols = train$target_names)))[[1]])

explainer = explain_mlr3(final_model$model, data = train_set,
                         y = Y_train,
                         label= "random forest")
# feature importance
effect = model_parts(explainer)
plot(effect) + 
  ggtitle("Featute Importance") + theme_base() + 
  theme(legend.position = "none",
        plot.subtitle = element_blank())
# pd
profiles = model_profile(explainer,
                         variables = "income",
                         type = "partial")
plot(profiles) +
  theme_base() +
  theme(legend.position = "top",
        plot.subtitle = element_blank()) +
  ggtitle("Partial Dependence for RF base model") 
# breakdown
# SHAP
bd <- predict_parts(explainer = explainer, 
                    new_observation = test$data(rows=1))
plot(bd) + 
  theme_base() +
  labs(fill="contribution sign") +
  theme(legend.position = "top",
        plot.subtitle = element_blank(),
        axis.text.y = element_text(size = 8)) 
# SHAP
shap <- predict_parts(explainer = explainer, 
                      new_observation = test$data(rows=1),
                      type="shap")
plot(shap) +
  theme_pander() +
  ggtitle("SHAP Analysis for rpart (First Sample)") +
  labs(fill="contribution sign") +
  theme(legend.position = "top",
        plot.subtitle = element_blank(),
        axis.text.y = element_text(size = 8)) 

```
